
// Function for calculation number of hours
function calculatePriceByHours() {
    const hours = parseInt(document.getElementById('hours').value);

    if (isNaN(hours) || hours <= 0) {
        document.getElementById('result-hours').innerText = 'Please, enter correct number of hours.';
        return;
    }

    // Basic price per first hour
    let basePrice = 100000;
    let price = basePrice * hours;  // Starting price

    // Set up a discount price for the next hours
    if (hours > 1) {
        price -= (hours - 1) * 50000;  // Discoun price for any hour after the first one
    }

    document.getElementById('result-hours').innerText = `Final price for ${hours} hours: ${price} som`;
}

// Function for calculation number of visits
function calculatePriceByVisits() {
    const visits = parseInt(document.getElementById('visits').value);

    if (isNaN(visits) || visits <= 0) {
        document.getElementById('result-visits').innerText = 'Please, enter correct number of visits.';
        return;
    }

    // Basic price for one visit
    let basePrice = 50000;
    let price = basePrice * visits;  // Starting price

    // Set up a discount price for the next visits
    if (visits > 1) {
        price -= (visits - 1) * 25000;  // Discount price for any visit after the first one
    }

    document.getElementById('result-visits').innerText = `Final price for ${visits} visits: ${price} som`;
}
